package com.jbk;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client5 {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Practice.class); 
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		Transaction tr = session.beginTransaction();
		Practice p = new Practice();
		p.setId(3);
		p.setName("sarthak");
		p.setSalary("30000");	//we delete data about --> : id 12 , name "karan", salary: "40000".
		session.delete(p);	
		tr.commit();
		
		session.close();	
		System.out.println("Data Delete Successfully");
	}
}

package com.jbk;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Client6 {

	public static void main(String[] args) {
		
	
	Configuration cfg = new Configuration();
	cfg.configure();
	cfg.addAnnotatedClass(Practice.class); 
	SessionFactory sf = cfg.buildSessionFactory();
	Session session = sf.openSession();
	  
	//return resultset or whole table from database
	Criteria criteria = session.createCriteria(Practice.class);
	List<Practice> list = criteria.list();
	System.out.println(list);
	
	
	session.close();
	}
}

package com.jbk;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;

public class Client14 {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Practice.class); 
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		//resultset or whole table
		Query query = session.createQuery("from Practice");
		List<Practice> list = query.list();
		
		System.out.println(list);
		
		session.close();

	}
}
